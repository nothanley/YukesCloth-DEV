import bpy
from .Bones import SkeletonAlign
from .YukesCloth import cloth_export_weights
from .MDL.MdlProps import *
from .YukesCloth import weight_paint
from bpy_extras.io_utils import ExportHelper

bl_info = {
    "name": "WWE 2K MDL Utilities",
    "author": "Hanleys",
    "version": (1, 0),
    "blender": (2, 93, 4),
    "description": "UI Panel utils for .MDL 3D format",
    "category": "Object",
}

class RetargetSkeletonPanel(bpy.types.Panel):
    bl_label = "Align Skeleton"
    bl_idname = "VIEW3D_PT_retarget_skeleton"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.retarget_skeleton_operator", text="Align Skeleton")

class RetargetSkeletonOperator(bpy.types.Operator):
    bl_idname = "object.retarget_skeleton_operator"
    bl_label = "Align Skeleton"

    def execute(self, context):
        SkeletonAlign.nope()
        return {'FINISHED'}

class YukesClothPanel(bpy.types.Panel):
    bl_label = "Yukes Cloth"
    bl_idname = "VIEW3D_PT_yukes_cloth"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.label(text="Source Object:")
        row.prop(context.scene, "ycl_source_mesh", text="")
        layout.operator("object.ycl_export_source", text="Export Sim Object (Source)")
        
        row = layout.row()
        row.label(text="Target Object:")
        row.prop(context.scene, "ycl_target_mesh", text="")
        layout.operator("object.ycl_export_target", text="Export Sim Object (Target)")
        
        row = layout.row()
        row.label(text="YCL Utilities:")
        row = layout.row()
        layout.operator("object.ycl_gen_vweights", text="Auto generate vertex weights")
        row = layout.row()
        layout.operator("object.ycl_export_all", text="Export All Meshes")


class YCLGenerateWeightPaint(bpy.types.Operator):
    bl_idname = "object.ycl_gen_vweights"
    bl_label = "Auto generate vertex weights"

    def execute(self, context):
        obj = bpy.context.active_object
        weight_paint.generate_sim_root_skin(obj)
        return {'FINISHED'}

class YCLExportSourceMesh(bpy.types.Operator):
    bl_idname = "object.ycl_export_source"
    bl_label = "Export Sim Object (Target)"
    filename_ext = ".jsim"
    filter_glob: bpy.props.StringProperty(default = '*.json;*.jsim',options = {'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        mesh = context.scene.ycl_source_mesh
        cloth_export_weights.export(mesh,self.filepath,is_source_mesh=True)
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class YCLExportTargetMesh(bpy.types.Operator):
    bl_idname = "object.ycl_export_target"
    bl_label = "Export Sim Object (Target)"
    filename_ext = ".jsim"
    filter_glob: bpy.props.StringProperty(default = '*.json;*.jsim',options = {'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        target_mesh = context.scene.ycl_target_mesh
        source_mesh = context.scene.ycl_source_mesh
        cloth_export_weights.export(target_mesh,self.filepath,is_source_mesh=False,src_link_mesh=source_mesh)
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
class YCLExportAll(bpy.types.Operator):
    bl_idname = "object.ycl_export_all"
    bl_label = "Export All"
    filename_ext = ".jsim"
    filter_glob: bpy.props.StringProperty(default = '*.json;*.jsim',options = {'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        source = context.scene.ycl_source_mesh
        source_path = self.filepath.split(".")[0] + "_source.jsim"
        cloth_export_weights.export(source,source_path,is_source_mesh=True)

        target = context.scene.ycl_target_mesh
        target_path = self.filepath.split(".")[0] + "_target.jsim"
        cloth_export_weights.export(target,target_path,is_source_mesh=False,src_link_mesh=source)

        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class MDLProperties(bpy.types.PropertyGroup):
    # # Function to update the boolean properties based on the appearance flag value.
    def update_bool_properties(self):
        self.entrance_only = (self.appearance_flag == 129)
        self.ring_only = (self.appearance_flag == 130)
        self.all_scenes = (self.appearance_flag == 128)
        self.other = (self.appearance_flag == 131)

    update: bpy.props.BoolProperty(name="Appearance Flag", default=False)
    appearance_flag: bpy.props.IntProperty(name="Appearance Flag", default=128)    
    sub_flag: bpy.props.IntProperty(name="Sub Flag", default=-1)       
    other_value: bpy.props.IntProperty( default=0,update=update_custom_value)
    entrance_only: bpy.props.BoolProperty(name="Entrance Only", default=False, update=lambda self, context: update_values(self, context, "entrance_only") )
    ring_only: bpy.props.BoolProperty(name="Ring Only", default=False, update=lambda self, context: update_values(self, context, "ring_only"))
    all_scenes: bpy.props.BoolProperty(name="All Scenes", default=False, update=lambda self, context: update_values(self, context, "all_scenes"))
    other: bpy.props.BoolProperty(name="Other", default=False, update=lambda self, context: update_values(self, context, "other"))


class MDLPanel(bpy.types.Panel):
    bl_label = "Scene Flags"
    bl_idname = "OBJECT_PT_MDLPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'

    def draw(self, context):
        layout = self.layout
        obj = context.object

        if obj is not None and hasattr(obj, "mdl_properties"):        
            split = layout.split(factor=0.625)
            
            col = split.column()
            col.label(text='Appearance Flag: ')
            
            col = split.column()
            col.prop(obj.mdl_properties, "appearance_flag", text="", )
            col.enabled = False

            row = layout.row()
            row.prop(obj.mdl_properties, "ring_only"); row = layout.row()
            row.prop(obj.mdl_properties, "entrance_only"); row = layout.row()
            row.prop(obj.mdl_properties, "all_scenes"); row = layout.row()
            row.prop(obj.mdl_properties, "other")

            split = row.split(factor=1)
            col = split.column()
            col.prop(obj.mdl_properties, "other_value", text="", emboss=True)
            
            row = layout.row()
            row.label(text= "Sub Flag:")
            split = row.split(factor=1)
            col = split.column()
            col.prop(obj.mdl_properties, "sub_flag", text="", emboss=True )


def register():
    bpy.utils.register_class(MDLProperties)
    bpy.utils.register_class(MDLPanel)
    bpy.types.Object.mdl_properties = bpy.props.PointerProperty(type=MDLProperties)

    bpy.utils.register_class(RetargetSkeletonPanel)
    bpy.utils.register_class(RetargetSkeletonOperator)

    bpy.utils.register_class(YukesClothPanel)
    bpy.utils.register_class(YCLExportSourceMesh)
    bpy.utils.register_class(YCLExportTargetMesh)
    bpy.utils.register_class(YCLExportAll)
    bpy.utils.register_class(YCLGenerateWeightPaint)

    bpy.types.Scene.ycl_source_object = bpy.props.StringProperty(name="Source Object")
    bpy.types.Scene.ycl_target_object = bpy.props.StringProperty(name="Target Object")
    bpy.types.Scene.ycl_source_mesh = bpy.props.PointerProperty(type=bpy.types.Mesh, name="Source Mesh")
    bpy.types.Scene.ycl_target_mesh = bpy.props.PointerProperty(type=bpy.types.Mesh, name="Target Mesh")
    bpy.types.Scene.filepath = bpy.props.StringProperty(subtype="FILE_PATH")


def unregister():
    bpy.utils.unregister_class(MDLProperties)
    bpy.utils.unregister_class(MDLPanel)

    bpy.utils.unregister_class(RetargetSkeletonPanel)
    bpy.utils.unregister_class(RetargetSkeletonOperator)

    bpy.utils.unregister_class(YukesClothPanel)
    bpy.utils.unregister_class(YCLExportSourceMesh)
    bpy.utils.unregister_class(YCLExportTargetMesh)
    bpy.utils.unregister_class(YCLExportAll)
    bpy.utils.unregister_class(YCLGenerateWeightPaint)

    del bpy.types.Scene.ycl_source_object
    del bpy.types.Scene.ycl_target_object
    del bpy.types.Object.mdl_properties
    del bpy.types.Scene.ycl_source_mesh
    del bpy.types.Scene.ycl_target_mesh
    del bpy.types.Scene.filepath

if __name__ == "__main__":
    register()
