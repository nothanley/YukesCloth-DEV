import bpy


def check_parenting( base_armature ):
    base_bones = {bone.name: bone for bone in base_armature.data.edit_bones}

    if ("J_Root" in base_bones and "J_Hips" in base_bones):
        base_bone = base_bones["J_Hips"]
        base_bone.parent = base_bones["J_Root"]

def alignArmature(target_armature, base_armature):

    bpy.context.view_layer.objects.active = base_armature
    bpy.ops.object.mode_set(mode='EDIT')

    for target_bone in target_armature.data.edit_bones:
        base_bones = {bone.name: bone for bone in base_armature.data.edit_bones}

        # Check if the base armature already has a bone with the same name
        if target_bone.name in base_bones:
            continue  # Skip this bone, as it already exists in the base armature

        # If the base armature does not have this bone, add it
        new_bone = base_armature.data.edit_bones.new(target_bone.name)
        targetMatrix = target_bone.matrix

        new_bone.head = target_bone.head
        new_bone.tail = target_bone.tail
        # print ("BONE: " , new_bone.name)

        # If the target bone has a parent bone, find or create the corresponding parent bone in the base armature
        if target_bone.parent:
            parent_name = target_bone.parent.name
            if parent_name in base_bones:
                new_bone.parent = base_bones[parent_name]
        
        new_bone.matrix = targetMatrix
        # print( "Target Matrix: ", targetMatrix)
        # print( "New Bone Matrix: ", new_bone.matrix)



def evaluateTargetBaseArmatures( armature_1, armature_2 ):
    # Check if either armature has a bone named "J_Hair"
    arm1_has_jhair = "J_Hair" in armature_1.data.bones
    arm2_has_jhair = "J_Hair" in armature_2.data.bones

    if arm1_has_jhair and not arm2_has_jhair:
        target_armature = armature_1
        base_armature = armature_2
    elif arm2_has_jhair and not arm1_has_jhair:
        target_armature = armature_2
        base_armature = armature_1
    else:
        # If both armatures have "J_Hair", compare the number of bones in each
        if len(armature_1.data.bones) > len(armature_2.data.bones):
            target_armature = armature_1
            base_armature = armature_2
        else:
            target_armature = armature_2
            base_armature = armature_1
    
    return target_armature, base_armature

def hairNodeTotal( skel ):
    hairBones = 0
    for bone in skel.edit_bones:
        if bone.name == "J_Hair":
            hairBones+=1
    return hairBones


def filterSelection(objSel):
    outSel = []
    for obj in objSel:
        if bpy.context.object.type == 'ARMATURE':
            outSel.append(obj)
    return outSel

def nope():
    userSelection = filterSelection( bpy.context.selected_objects )

    if ( len(userSelection) != 2 ):
        raise TypeError( "Select TWO skeletons to align armatures.")
        return

    baseSkeleton , targetSkeleton = evaluateTargetBaseArmatures( userSelection[0], userSelection[1] )
    alignArmature( baseSkeleton, targetSkeleton )
    check_parenting( targetSkeleton )   
    bpy.ops.object.mode_set(mode='OBJECT') 

    print("Target Skeleton: " , targetSkeleton.name , "Base Skeleton: " , baseSkeleton.name )
