import bpy

# Define the update function that gets called whenever the appearance_flag property is updated.
def update_appearance_flag(self, context):
    setattr(self,"appearance_flag",129) if self.entrance_only else None
    setattr(self,"appearance_flag",130) if self.ring_only else None
    setattr(self,"appearance_flag",128) if self.all_scenes else None
    setattr(self,"appearance_flag",self.other_value) if self.other else None

def isolateValue(self,context,type):
    if not self.update: return None
    for prop_name in dir(self):
        prop = getattr(self, prop_name)
        if isinstance(prop, bool) and prop_name != type:
            setattr(self,prop_name,False)
        if isinstance(prop, bool) and prop_name == type:
            setattr(self,type,True)

def update_model_name_string(self,context,type):
    obj = bpy.context.view_layer.objects.active
    if (obj.type!="MESH"): return
    
    meshName = obj.name
    #cull flags
    meshName = meshName.replace("!",""); meshName = meshName.replace("$","")
    if self.ring_only == True: obj.name = meshName+("$")
    if self.entrance_only == True: obj.name = meshName+("!")
    if self.all_scenes == True: obj.name = meshName
    
    return None

def update_values(self,context, type):
    if self.update: return None
    # Iterate over all boolean properties in the PropertyGroup
    self.update = True
    isolateValue(self,context,type)
    update_appearance_flag(self,context)
    update_model_name_string(self,context,type)
    self.update = False
    return None

def update_custom_value(self,context):
    #toggle Box
    update_values(self,context,"other")
    setattr(self,"appearance_flag",self.other_value)
    return None